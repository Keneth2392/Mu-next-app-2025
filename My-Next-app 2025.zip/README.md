# My Next App

Este es un proyecto básico con Next.js listo para subir a GitHub.

## Scripts disponibles

- `npm run dev` → Inicia el servidor de desarrollo
- `npm run build` → Compila la app para producción
- `npm start` → Corre la app en producción
