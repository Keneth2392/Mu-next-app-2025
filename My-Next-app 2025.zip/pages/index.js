export default function Home() {
  return (
    <div>
      <h1>Hola, Next.js está funcionando 🚀</h1>
      <p>Este es tu proyecto inicial.</p>
    </div>
  );
}
